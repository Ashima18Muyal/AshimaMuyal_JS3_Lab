

import { WeatherApp } from "./weather-app/weather-app.js"; 

const weatherAppObj = new WeatherApp();
weatherAppObj.init();